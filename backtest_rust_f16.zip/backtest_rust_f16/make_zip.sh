zip -r backtest_rust.zip src/*.rs Cargo.toml data results.csv data_downloader_freqtrade make_zip.sh -x *binance*/*

