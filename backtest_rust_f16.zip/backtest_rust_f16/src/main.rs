use chrono::prelude::*; // This crate provides easy-to-use date and time functions
use chrono::Utc;
use rayon::prelude::*;
use rayon::ThreadPoolBuilder;
use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::{Arc, Mutex};
use std::time::Instant;
use half::f16;
mod ta_wrapper;
mod utils;

///////////////////////////////////////////////////////////////////////////////////////////////////////
fn main() {
    let start = Instant::now();

    let nb_threads = 4;

    // Load data
    let filepath = "./data/ETH_USDT-1h.json";

    println!("Doing: {:}", utils::get_filename(filepath));

    let (timestamps, close_prices) = utils::load_data_file(&filepath);

    if let Some(&first_timestamp) = timestamps.first() {
        let first_date = Utc.timestamp_millis_opt(first_timestamp).unwrap();
        println!("First timestamp : {}", first_date.format("%Y-%m-%d"));
    }
    if let Some(&last_timestamp) = timestamps.last() {
        let last_date = Utc.timestamp_millis_opt(last_timestamp).unwrap();
        println!("Last  timestamp : {}", last_date.format("%Y-%m-%d"));
    }

    // Calculate all indicators
    println!("Calculating all indicators...");

    let ema_store = Arc::new(ta_wrapper::EMAStore::new(&close_prices, 3, 600));
    let close_prices = Arc::new(close_prices);

    println!("Calculated all indicators.");

    // Run backtests

    println!("Running all backtests on {} threads...", nb_threads);

    // Prepare for collecting results
    let best_results = Arc::new(Mutex::new((f16::MIN, f16::MIN, f16::MIN, 0, 0)));

    // Configure and use a custom thread pool
    let pool = ThreadPoolBuilder::new().num_threads(nb_threads).build().unwrap();

    let total_iterations = (5..=600).into_iter().map(|p1| (p1 + 1..=600).count()).sum::<usize>();
    let progress_counter = Arc::new(AtomicUsize::new(0));

    pool.install(|| {
        (5..=600).into_par_iter().for_each(|period1| {
            for period2 in 6..=600 {
                if period2 > period1 {
                    let ema1 = ema_store.get_ema(period1);
                    let ema2 = ema_store.get_ema(period2);

                    let (port_value, max_drawdown, sharpe_ratio) = backtest(&close_prices, &ema1, &ema2);

                    let mut best = best_results.lock().unwrap();
                    if sharpe_ratio > best.2 {
                        *best = (port_value, max_drawdown, sharpe_ratio, period1, period2);
                    }

                    // Progress update
                    let count = progress_counter.fetch_add(1, Ordering::SeqCst) + 1;
                    if count % 10000 == 0 || count == total_iterations {
                        let percentage = (count as f32 / total_iterations as f32) * 100.0;
                        println!("  ...Progress: {:6}/{:6} iterations completed {:5.1}%.", count, total_iterations, percentage);
                    }
                }
            }
        });
    });

    println!("Done");
    let best = best_results.lock().unwrap();
    println!("Best result: sharpe: {:.3}, max_dd: {:.2}, Period1: {}, Period2: {}", best.2, best.1, best.3, best.4);

    //utils::write_to_file(utils::get_filename(filepath), best.0, best.1, best.2, best.3, best.4).expect("Failed to write to file");

    let duration = start.elapsed();
    println!("Time elapsed: {:?}", duration);
}

///////////////////////////////////////////////////////////////////////////////////////////////////////

fn backtest(close_prices: &Vec<f16>, ema1: &Vec<f16>, ema2: &Vec<f16>) -> (f16, f16, f16) {
    let mut usdt: f16 = f16::from_f64(1000.0); // Starting with 1000 USDT
    let mut asset_quantity: f16 = f16::from_f64(0.0); // Quantity of the asset we own
    let mut in_position = false; // Flag to track if we are currently holding the asset

    let mut portfolio_values = vec![usdt]; // Track portfolio values over time
    let mut returns = vec![]; // To calculate the Sharpe Ratio
    let fee: f16 = f16::from_f64(0.15); // %, buy and sell fees

    // Iterate through close_prices to decide when to buy/sell
    for i in 1..close_prices.len() {
        let current_price = close_prices[i];
        //let previous_price = close_prices[i - 1];
        let previous_value = portfolio_values.last().unwrap().clone();

        if !in_position && ema1[i] > ema2[i] {
            // Enter position: buy as much as possible with all USDT
            asset_quantity = usdt / current_price * (f16::from_f64(1.0) - fee / f16::from_f64(100.0));
            usdt = f16::from_f64(0.0);
            in_position = true;
            //println!("Buying at price {}: new asset quantity {}", current_price, asset_quantity);
        } else if in_position && ema1[i] < ema2[i] {
            // Exit position: sell all of the asset
            usdt = asset_quantity * current_price * (f16::from_f64(1.0) - fee / f16::from_f64(100.0));
            asset_quantity = f16::from_f64(0.0);
            in_position = false;
            //println!("Selling at price {}: new USDT amount {}", current_price, usdt);
        }

        let current_value = if in_position { asset_quantity * current_price } else { usdt };
        portfolio_values.push(current_value);
        if i > 1 {
            // Avoid the first element which has no previous value to compare
            returns.push((current_value - previous_value) / previous_value);
        }
    }

    let final_value = *portfolio_values.last().unwrap();
    let max_drawdown = utils::calculate_max_drawdown(&portfolio_values);
    let sharpe_ratio = utils::calculate_sharpe_ratio(&returns, f16::from_f64(0.0), f16::from_f64(24.0 * 365.0));

    (final_value, max_drawdown, sharpe_ratio)
}

///////////////////////////////////////////////////////////////////////////////////////////////////////
