use anyhow::{Context, Result};
use chrono::prelude::*; // This crate provides easy-to-use date and time functions
use serde::{Deserialize, Serialize};
use std::io::{BufWriter, Write};
use std::{fs::File, fs::OpenOptions, io::BufReader, path::Path};
use half::f16;

#[derive(Serialize, Deserialize)]
pub struct MarketData {
    timestamp: i64,
    open: f64,
    high: f64,
    low: f64,
    close: f64,
    volume: f64,
}

pub fn convert_f16_to_f64(input: Vec<f16>) -> Vec<f64> {
    input.iter().map(|&num| num.to_f64()).collect()
}

pub fn convert_to_f16(vec_f64: Vec<f64>) -> Vec<f16> {
    vec_f64.into_iter().map(|value| {
        if value.is_nan() {
            // Handle NaN values
            f16::NAN
        } else if value.is_infinite() {
            // Handle infinity by checking if it's positive or negative
            if value.is_sign_positive() { f16::INFINITY } else { f16::NEG_INFINITY }
        } else {
            // Convert f64 to f16 using from_f64 method
            let converted = f16::from_f64(value);
            // Check for overflow and underflow
            if (converted == f16::INFINITY || converted == f16::NEG_INFINITY) && value.abs() != f64::INFINITY {
                // Use infinity to indicate overflow
                if value > 0.0 { f16::INFINITY } else { f16::NEG_INFINITY }
            } else if converted == f16::ZERO && value != 0.0 && value.abs() < f64::from(f16::MIN_POSITIVE) {
                // Use zero to indicate underflow
                f16::ZERO
            } else {
                // Use the converted value
                converted
            }
        }
    }).collect()
}

pub fn convert_f64_to_f32(f64_vec: Vec<f64>) -> Vec<f32> {
    f64_vec.into_iter().map(|value: f64| value as f32).collect()
}

pub fn convert_f32_to_f64(f32_vec: Vec<f32>) -> Vec<f64> {
    f32_vec.into_iter().map(|value: f32| value as f64).collect()
}

pub fn load_data_file(filepath: &str) -> (Vec<i64>, Vec<f16>) {
    let (timestamps, close_prices);
    match load_market_data(&filepath) {
        Ok(data) => {
            let extracted = extract_fields(&data);
            timestamps = extracted.0; // Assign values within the match block
            close_prices = extracted.1;
        }
        Err(e) => {
            println!("Failed to load data: {:?}", e);
            timestamps = Vec::new();
            close_prices = Vec::new();
        }
    }
    (timestamps, convert_to_f16(close_prices))
}

pub fn calculate_max_drawdown(portfolio_values: &[f16]) -> f16 {
    if portfolio_values.is_empty() {
        return f16::from_f32(0.0); // Return 0.0 immediately if input is empty to avoid panics
    }

    // Convert f16 inputs to f32 for calculation
    let portfolio_values_f32: Vec<f32> = portfolio_values.iter().map(|&x| x.to_f32()).collect();

    let mut max_drawdown = 0.0f32;
    let mut peak = portfolio_values_f32[0];

    for &value in portfolio_values_f32.iter() {
        if value > peak {
            peak = value;
        }
        let drawdown = (peak - value) / peak;
        if drawdown > max_drawdown {
            max_drawdown = drawdown;
        }
    }

    // Convert the result back to f16 and multiply by 100 to return percentage
    f16::from_f32(max_drawdown * 100.0)
}

pub fn calculate_sharpe_ratio(returns: &[f16], risk_free_rate: f16, periods_per_year: f16) -> f16 {
    if returns.is_empty() {
        return f16::from_f32(0.0); // Return 0 if no returns data is available to avoid division by zero
    }

    // Convert f16 inputs to f32 for calculation
    let returns_f32: Vec<f32> = returns.iter().map(|&x| x.to_f32()).collect();
    let risk_free_rate_f32 = risk_free_rate.to_f32();
    let periods_per_year_f32 = periods_per_year.to_f32();

    let mean_return = returns_f32.iter().sum::<f32>() / returns_f32.len() as f32;
    let std_dev_return = (returns_f32.iter().map(|&r| (r - mean_return).powi(2)).sum::<f32>() / (returns_f32.len() - 1) as f32).sqrt();
    let annualized_std_dev = std_dev_return / (periods_per_year_f32).sqrt();

    let result = if annualized_std_dev == 0.0 {
        0.0 // Avoid division by zero if standard deviation is zero
    } else {
        (mean_return - risk_free_rate_f32) / annualized_std_dev
    };

    // Convert the result back to f16
    f16::from_f32(result)
}

pub fn write_to_file(ohlcv_file: &str, port_value: f32, max_dd: f32, sharpe_ratio: f32, period1: usize, period2: usize) -> std::io::Result<()> {
    let file = OpenOptions::new()
        .write(true)
        .truncate(true) // Truncate the file each time it's opened
        .create(true)
        .open("results.csv")?;

    let mut writer = BufWriter::new(file);

    // Check if file is empty to write headers
    if writer.get_ref().metadata()?.len() == 0 {
        writeln!(writer, "Filename,Date,portfolio_val,max_dd,sharpe_ratio,Period1,Period2")?;
    }

    let now = Utc::now();
    writeln!(
        writer,
        "{},{},{:.3},{:.3},{:.3},{},{}",
        ohlcv_file,
        now.to_rfc3339(),
        port_value,
        max_dd,
        sharpe_ratio,
        period1,
        period2
    )?;

    writer.flush() // Make sure to flush the buffer
}

pub fn load_market_data(filepath: impl AsRef<Path>) -> Result<Vec<MarketData>> {
    let file = File::open(filepath.as_ref()).with_context(|| format!("Failed to open file: {:?}", filepath.as_ref()))?;
    let reader = BufReader::new(file);
    let data = serde_json::from_reader(reader).with_context(|| "Failed to parse JSON data")?;
    Ok(data)
}

pub fn extract_fields(data: &[MarketData]) -> (Vec<i64>, Vec<f64>) {
    let timestamps = data.iter().map(|entry| entry.timestamp).collect();
    let close_prices = data.iter().map(|entry| entry.close).collect();
    (timestamps, close_prices)
}

pub fn get_filename(path_str: &str) -> &str {
    let path = Path::new(path_str);

    // Extract the file stem (base name without extension)
    if let Some(stem) = path.file_stem() {
        if let Some(stem_str) = stem.to_str() {
            //println!("Base name: {}", stem_str);
            return stem_str;
        } else {
            println!("File stem contains invalid UTF-8 characters.");
            return "error";
        }
    } else {
        println!("No base name found in the path.");
        return "error";
    }
}
